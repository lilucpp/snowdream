// accross_session.cpp : �������̨Ӧ�ó������ڵ㡣
//


#include "stdafx.h"
#include <Windows.h>

DWORD MessageBoxSecure(HWND hWnd,LPCTSTR lpText,LPCTSTR lpCaption,UINT uType)
{
	DWORD retunvalue;

	HDESK desktop=NULL;
	HDESK old_desktop;
	desktop = OpenInputDesktop(0, FALSE,DESKTOP_CREATEMENU | DESKTOP_CREATEWINDOW |DESKTOP_ENUMERATE | DESKTOP_HOOKCONTROL |DESKTOP_WRITEOBJECTS | DESKTOP_READOBJECTS |DESKTOP_SWITCHDESKTOP | GENERIC_WRITE);
	old_desktop = GetThreadDesktop(GetCurrentThreadId());
	if (desktop && 	old_desktop && old_desktop!=desktop)
	{
		SetThreadDesktop(desktop);
		retunvalue=MessageBox(hWnd,lpText,lpCaption,uType);
		SetThreadDesktop(old_desktop);
		CloseDesktop(desktop);
	}
	else retunvalue=0;
	
	return retunvalue;
}

int _tmain(int argc, _TCHAR* argv[])
{

	MessageBoxSecure(NULL, L"this is test!", L"title", 0);
	return 0;
}

